<?php
// Inclure les fichiers de configuration
require_once __DIR__ . '/../config/config.php';

// Vérifier la connexion à la base de données
$conn = getDBConnection();

// Récupérer l'ID de la session
$session_id = isset($_GET['id']) ? intval($_GET['id']) : 0;

// Vérifier si la session existe
$sql = "SELECT s.*, 
        p.nom as pilote_nom, p.prenom as pilote_prenom,
        m.marque as moto_marque, m.modele as moto_modele,
        c.nom as circuit_nom
        FROM sessions s
        JOIN pilotes p ON s.pilote_id = p.id
        JOIN motos m ON s.moto_id = m.id
        JOIN circuits c ON s.circuit_id = c.id
        WHERE s.id = ?";

$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $session_id);
$stmt->execute();
$result = $stmt->get_result();

if ($result && $result->num_rows > 0) {
    $session = $result->fetch_assoc();
} else {
    // Rediriger si la session n'existe pas
    header("Location: " . url('sessions/'));
    exit;
}

// Récupérer les données techniques
$sql = "SELECT * FROM donnees_techniques_session WHERE session_id = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $session_id);
$stmt->execute();
$result = $stmt->get_result();

if ($result && $result->num_rows > 0) {
    $donnees_techniques = $result->fetch_assoc();
} else {
    $donnees_techniques = [];
}

// Récupérer les chronos
$sql = "SELECT * FROM chronos WHERE session_id = ? ORDER BY tour";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $session_id);
$stmt->execute();
$result = $stmt->get_result();

$chronos = [];
if ($result && $result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $chronos[] = $row;
    }
}

// Calculer les statistiques des chronos
$stats = [
    'min' => 0,
    'max' => 0,
    'avg' => 0,
    'best_lap' => 0,
    'worst_lap' => 0
];

if (!empty($chronos)) {
    $times = array_column($chronos, 'temps');
    $stats['min'] = min($times);
    $stats['max'] = max($times);
    $stats['avg'] = array_sum($times) / count($times);
    $stats['best_lap'] = array_search($stats['min'], $times) + 1;
    $stats['worst_lap'] = array_search($stats['max'], $times) + 1;
}

// Récupérer les recommandations
$sql = "SELECT * FROM recommandations WHERE session_id = ? ORDER BY created_at DESC";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $session_id);
$stmt->execute();
$result = $stmt->get_result();

$recommandations = [];
if ($result && $result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $recommandations[] = $row;
    }
}

// Inclure l'en-tête
include_once __DIR__ . '/../includes/header.php';
?>

<div class="dashboard-panel">
    <div class="dashboard-panel-title">
        <i class="fas fa-tachometer-alt"></i>
        <h3>Tableau de Bord - Session <?php echo htmlspecialchars($session['type']); ?></h3>
    </div>
    
    <div class="session-header">
        <div class="session-info">
            <h4><?php echo htmlspecialchars($session['pilote_prenom'] . ' ' . $session['pilote_nom']); ?></h4>
            <p><?php echo htmlspecialchars($session['moto_marque'] . ' ' . $session['moto_modele']); ?></p>
            <p><?php echo htmlspecialchars($session['circuit_nom']); ?></p>
            <p>Date: <?php echo date('d/m/Y', strtotime($session['date'])); ?></p>
            <p>Conditions: <?php echo htmlspecialchars($session['conditions'] ?? 'Non spécifiées'); ?></p>
        </div>
        <div class="session-actions">
            <a href="<?php echo url('sessions/edit.php?id=' . $session_id); ?>" class="btn btn-primary">
                <i class="fas fa-edit"></i> Modifier
            </a>
            <a href="<?php echo url('sessions/view.php?id=' . $session_id); ?>" class="btn">
                <i class="fas fa-eye"></i> Vue détaillée
            </a>
        </div>
    </div>
    
    <div class="dashboard-grid">
        <!-- Panneau des chronos -->
        <div class="dashboard-panel">
            <div class="dashboard-panel-title">
                <i class="fas fa-stopwatch"></i>
                <h3>Chronos</h3>
            </div>
            
            <?php if (!empty($chronos)): ?>
                <div class="chart-container">
                    <div class="chart-title">Évolution des chronos</div>
                    <canvas id="chronosChart"></canvas>
                </div>
                
                <div class="stats-container">
                    <div class="stat-item">
                        <div class="stat-label">Meilleur tour</div>
                        <div class="stat-value"><?php echo formatChrono($stats['min']); ?></div>
                        <div class="stat-info">Tour <?php echo $stats['best_lap']; ?></div>
                    </div>
                    <div class="stat-item">
                        <div class="stat-label">Temps moyen</div>
                        <div class="stat-value"><?php echo formatChrono($stats['avg']); ?></div>
                    </div>
                    <div class="stat-item">
                        <div class="stat-label">Pire tour</div>
                        <div class="stat-value"><?php echo formatChrono($stats['max']); ?></div>
                        <div class="stat-info">Tour <?php echo $stats['worst_lap']; ?></div>
                    </div>
                </div>
            <?php else: ?>
                <div class="alert alert-info">
                    <i class="fas fa-info-circle"></i> Aucun chrono enregistré pour cette session.
                </div>
            <?php endif; ?>
        </div>
        
        <!-- Panneau des réglages -->
        <div class="dashboard-panel">
            <div class="dashboard-panel-title">
                <i class="fas fa-sliders-h"></i>
                <h3>Réglages</h3>
            </div>
            
            <div class="settings-grid">
                <div class="setting-group">
                    <h4>Suspension avant</h4>
                    
                    <div class="setting-control">
                        <div class="setting-label">Précharge</div>
                        <div class="setting-slider">
                            <div class="setting-slider-fill" style="width: <?php echo ($donnees_techniques['precharge_avant'] ?? 0) * 10; ?>%;"></div>
                            <div class="setting-slider-handle" style="left: <?php echo ($donnees_techniques['precharge_avant'] ?? 0) * 10; ?>%;"></div>
                        </div>
                        <div class="setting-value"><?php echo $donnees_techniques['precharge_avant'] ?? '-'; ?> mm</div>
                    </div>
                    
                    <div class="setting-control">
                        <div class="setting-label">Compression basse</div>
                        <div class="setting-slider">
                            <div class="setting-slider-fill" style="width: <?php echo ($donnees_techniques['compression_basse_avant'] ?? 0) * 5; ?>%;"></div>
                            <div class="setting-slider-handle" style="left: <?php echo ($donnees_techniques['compression_basse_avant'] ?? 0) * 5; ?>%;"></div>
                        </div>
                        <div class="setting-value"><?php echo $donnees_techniques['compression_basse_avant'] ?? '-'; ?></div>
                    </div>
                    
                    <div class="setting-control">
                        <div class="setting-label">Détente</div>
                        <div class="setting-slider">
                            <div class="setting-slider-fill" style="width: <?php echo ($donnees_techniques['detente_avant'] ?? 0) * 5; ?>%;"></div>
                            <div class="setting-slider-handle" style="left: <?php echo ($donnees_techniques['detente_avant'] ?? 0) * 5; ?>%;"></div>
                        </div>
                        <div class="setting-value"><?php echo $donnees_techniques['detente_avant'] ?? '-'; ?></div>
                    </div>
                </div>
                
                <div class="setting-group">
                    <h4>Suspension arrière</h4>
                    
                    <div class="setting-control">
                        <div class="setting-label">Précharge</div>
                        <div class="setting-slider">
                            <div class="setting-slider-fill" style="width: <?php echo ($donnees_techniques['precharge_arriere'] ?? 0) * 10; ?>%;"></div>
                            <div class="setting-slider-handle" style="left: <?php echo ($donnees_techniques['precharge_arriere'] ?? 0) * 10; ?>%;"></div>
                        </div>
                        <div class="setting-value"><?php echo $donnees_techniques['precharge_arriere'] ?? '-'; ?> mm</div>
                    </div>
                    
                    <div class="setting-control">
                        <div class="setting-label">Compression basse</div>
                        <div class="setting-slider">
                            <div class="setting-slider-fill" style="width: <?php echo ($donnees_techniques['compression_basse_arriere'] ?? 0) * 5; ?>%;"></div>
                            <div class="setting-slider-handle" style="left: <?php echo ($donnees_techniques['compression_basse_arriere'] ?? 0) * 5; ?>%;"></div>
                        </div>
                        <div class="setting-value"><?php echo $donnees_techniques['compression_basse_arriere'] ?? '-'; ?></div>
                    </div>
                    
                    <div class="setting-control">
                        <div class="setting-label">Détente</div>
                        <div class="setting-slider">
                            <div class="setting-slider-fill" style="width: <?php echo ($donnees_techniques['detente_arriere'] ?? 0) * 5; ?>%;"></div>
                            <div class="setting-slider-handle" style="left: <?php echo ($donnees_techniques['detente_arriere'] ?? 0) * 5; ?>%;"></div>
                        </div>
                        <div class="setting-value"><?php echo $donnees_techniques['detente_arriere'] ?? '-'; ?></div>
                    </div>
                </div>
            </div>
            
            <div class="transmission-info">
                <h4>Transmission</h4>
                <div class="transmission-grid">
                    <div class="transmission-item">
                        <div class="transmission-label">Pignon avant</div>
                        <div class="transmission-value"><?php echo $session['pignon_avant'] ?? '-'; ?> dents</div>
                    </div>
                    <div class="transmission-item">
                        <div class="transmission-label">Pignon arrière</div>
                        <div class="transmission-value"><?php echo $session['pignon_arriere'] ?? '-'; ?> dents</div>
                    </div>
                    <div class="transmission-item">
                        <div class="transmission-label">Rapport</div>
                        <div class="transmission-value">
                            <?php 
                            if (!empty($session['pignon_avant']) && !empty($session['pignon_arriere'])) {
                                echo number_format($session['pignon_arriere'] / $session['pignon_avant'], 2);
                            } else {
                                echo '-';
                            }
                            ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <!-- Panneau des recommandations -->
    <div class="dashboard-panel">
        <div class="dashboard-panel-title">
            <i class="fas fa-robot"></i>
            <h3>Recommandations IA</h3>
        </div>
        
        <?php if (!empty($recommandations)): ?>
            <div class="recommendations-list">
                <?php foreach ($recommandations as $index => $recommandation): ?>
                    <?php 
                    $validationClass = '';
                    if ($recommandation['validation'] === 'positif') {
                        $validationClass = 'validation-positive';
                    } else if ($recommandation['validation'] === 'negatif') {
                        $validationClass = 'validation-negative';
                    } else if ($recommandation['validation'] === 'neutre') {
                        $validationClass = 'validation-neutral';
                    }
                    ?>
                    <div class="recommendation-item <?php echo $validationClass; ?>">
                        <div class="recommendation-header">
                            <span class="recommendation-date"><?php echo date('d/m/Y H:i', strtotime($recommandation['created_at'])); ?></span>
                            <span class="recommendation-source"><?php echo $recommandation['source'] === 'chatgpt' ? 'ChatGPT' : 'Communautaire'; ?></span>
                        </div>
                        <div class="recommendation-problem"><strong>Problème :</strong> <?php echo htmlspecialchars($recommandation['probleme']); ?></div>
                        <div class="recommendation-solution"><strong>Solution :</strong> <?php echo nl2br(htmlspecialchars($recommandation['solution'])); ?></div>
                        
                        <?php if ($recommandation['validation']): ?>
                            <div class="recommendation-validation">
                                <?php if ($recommandation['validation'] === 'positif'): ?>
                                    <span class="validation-badge positive">✅ Efficace</span>
                                <?php elseif ($recommandation['validation'] === 'negatif'): ?>
                                    <span class="validation-badge negative">❌ Inefficace</span>
                                <?php else: ?>
                                    <span class="validation-badge neutral">⚠️ Résultat mitigé</span>
                                <?php endif; ?>
                            </div>
                        <?php endif; ?>
                    </div>
                <?php endforeach; ?>
            </div>
        <?php else: ?>
            <div class="alert alert-info">
                <i class="fas fa-info-circle"></i> Aucune recommandation pour cette session.
            </div>
            <div class="recommendation-actions">
                <a href="<?php echo url('chatgpt/index.php?session_id=' . $session_id); ?>" class="btn btn-primary">
                    <i class="fas fa-robot"></i> Demander une recommandation
                </a>
            </div>
        <?php endif; ?>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
<script>
document.addEventListener('DOMContentLoaded', function() {
    <?php if (!empty($chronos)): ?>
    // Préparer les données pour le graphique des chronos
    var ctx = document.getElementById('chronosChart').getContext('2d');
    var chronosData = {
        labels: [<?php echo implode(', ', array_map(function($chrono) { return $chrono['tour']; }, $chronos)); ?>],
        datasets: [{
            label: 'Temps au tour',
            data: [<?php echo implode(', ', array_map(function($chrono) { return $chrono['temps']; }, $chronos)); ?>],
            borderColor: 'rgba(0, 168, 255, 1)',
            backgroundColor: 'rgba(0, 168, 255, 0.1)',
            borderWidth: 2,
            tension: 0.1,
            fill: true
        }]
    };
    
    var chronosChart = new Chart(ctx, {
        type: 'line',
        data: chronosData,
        options: {
            responsive: true,
            plugins: {
                legend: {
                    display: false
                },
                tooltip: {
                    callbacks: {
                        label: function(context) {
                            var time = context.raw;
                            var minutes = Math.floor(time / 60);
                            var seconds = Math.floor(time % 60);
                            var milliseconds = Math.floor((time % 1) * 1000);
                            return minutes + ':' + (seconds < 10 ? '0' : '') + seconds + '.' + (milliseconds < 100 ? '0' : '') + (milliseconds < 10 ? '0' : '') + milliseconds;
                        }
                    }
                }
            },
            scales: {
                y: {
                    reverse: true,
                    ticks: {
                        callback: function(value) {
                            var minutes = Math.floor(value / 60);
                            var seconds = Math.floor(value % 60);
                            var milliseconds = Math.floor((value % 1) * 1000);
                            return minutes + ':' + (seconds < 10 ? '0' : '') + seconds + '.' + (milliseconds < 100 ? '0' : '') + (milliseconds < 10 ? '0' : '') + milliseconds;
                        }
                    }
                }
            }
        }
    });
    <?php endif; ?>
});
</script>

<?php
// Fonction pour formater un chrono
function formatChrono($time) {
    $minutes = floor($time / 60);
    $seconds = floor($time % 60);
    $milliseconds = floor(($time % 1) * 1000);
    return $minutes . ':' . ($seconds < 10 ? '0' : '') . $seconds . '.' . ($milliseconds < 100 ? '0' : '') . ($milliseconds < 10 ? '0' : '') . $milliseconds;
}

// Inclure le pied de page
include_once __DIR__ . '/../includes/footer.php';
?>
