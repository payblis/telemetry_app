    </div>
</main>

<footer>
    <div class="footer-container">
        <div class="footer-content">
            <p>&copy; <?php echo date('Y'); ?> TeleMoto - Application d'Assistance Technique Moto Racing</p>
        </div>
    </div>
    <script src="<?php echo $js_path; ?>main.js"></script>
</footer>
</body>
</html>
